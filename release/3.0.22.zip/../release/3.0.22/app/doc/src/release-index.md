% Sigma16 run/download

[Sigma16 home page](https://jtod.github.io/Sigma16/)

